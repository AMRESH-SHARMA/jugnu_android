# 🔴 SECURITY & PRIVACY VULNERABILITIES

**Category:** Security  
**Total Issues:** 10 (4 Critical, 4 High, 2 Medium)  
**Priority:** URGENT - Fix Immediately

---

## 🔴 CRITICAL-001: Cleartext Traffic Enabled

**Severity:** Critical | **Risk:** 10/10  
**File:** `app/src/main/AndroidManifest.xml:38`  
**CWE:** CWE-319 (Cleartext Transmission of Sensitive Information)

### Problem
```xml
<application
    android:usesCleartextTraffic="true"
    ...>
```

The app allows unencrypted HTTP traffic, making it vulnerable to:
- Man-in-the-Middle (MITM) attacks
- Session hijacking
- Credential interception
- Call metadata exposure

### Impact
- **User Data:** All API calls can be intercepted
- **Tokens:** Session tokens, FCM tokens, RTM tokens exposed
- **Compliance:** Violates Google Play security requirements
- **Reputation:** Security breach risk

### Solution
```xml
<!-- AndroidManifest.xml -->
<application
    android:usesCleartextTraffic="false"
    ...>
```

### Additional Steps
1. Ensure all URLs use HTTPS
2. Add network security config:

```xml
<!-- res/xml/network_security_config.xml -->
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
```

3. Reference in manifest:
```xml
<application
    android:networkSecurityConfig="@xml/network_security_config"
    ...>
```

---

## 🔴 CRITICAL-002: Unencrypted Sensitive Data Storage

**Severity:** Critical | **Risk:** 9/10  
**File:** `app/src/main/java/com/example/app/core/preferences/user/data/UserPreferencesRepository.kt`  
**CWE:** CWE-311 (Missing Encryption of Sensitive Data)

### Problem
```kotlin
// Stored in plain text DataStore
val KEY_SESSION_ID = stringPreferencesKey("session_id")
val KEY_FCM_TOKEN = stringPreferencesKey("fcm_token")
val KEY_ACCOUNT_ID = stringPreferencesKey("account_id")
```

Sensitive data stored without encryption:
- Session IDs
- FCM tokens
- Account IDs
- Access tokens

### Impact
- **Device Compromise:** If device is rooted/compromised, all tokens accessible
- **Account Takeover:** Attacker can steal session and impersonate user
- **Data Breach:** User privacy violated

### Solution

**Step 1:** Add dependency in `build.gradle.kts`:
```kotlin
dependencies {
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
```

**Step 2:** Create encrypted DataStore:
```kotlin
// core/preferences/di/PreferencesModule.kt
@Module
@InstallIn(SingletonComponent::class)
object PreferencesModule {

    @Provides
    @Singleton
    fun provideEncryptedDataStore(
        @ApplicationContext context: Context
    ): DataStore<Preferences> {
        return PreferenceDataStoreFactory.create(
            produceFile = {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()

                val encryptedFile = EncryptedFile.Builder(
                    context,
                    File(context.filesDir, "datastore/user_prefs.preferences_pb"),
                    masterKey,
                    EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                ).build()

                encryptedFile.file
            }
        )
    }
}
```

**Step 3:** Update repository to use encrypted storage:
```kotlin
@Singleton
class SecureUserPreferencesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    // Same implementation, now encrypted automatically
    suspend fun saveSessionId(sessionId: String) {
        dataStore.edit { prefs ->
            prefs[KEY_SESSION_ID] = sessionId
        }
    }
}
```

---

## 🔴 CRITICAL-003: Hardcoded API Credentials & URLs

**Severity:** Critical | **Risk:** 8/10  
**File:** `app/src/main/java/com/example/app/utils/AppConstants.kt:10-11`  
**CWE:** CWE-798 (Use of Hard-coded Credentials)

### Problem
```kotlin
const val USE_DEFAULT_URL = true
const val DEFAULT_BASE_URL = "http://192.168.1.6:3001/api/v1/"
```

Issues:
- Development URL hardcoded in production APK
- Local IP address exposed
- HTTP (not HTTPS) used
- Backend infrastructure revealed

### Impact
- **Reverse Engineering:** Attackers can decompile APK and find URLs
- **Infrastructure Exposure:** Backend server location visible
- **Security Risk:** Development endpoints may have weaker security

### Solution

**Step 1:** Remove hardcoded URLs:
```kotlin
// AppConstants.kt
object AppConstants {
    const val REMOTE_CONFIG_URL = "https://storage.googleapis.com/jugnu-config-server/config.json"
    const val USE_DEFAULT_URL = false // Always false in production
    
    // Remove DEFAULT_BASE_URL completely
}
```

**Step 2:** Use BuildConfig for environment-specific URLs:
```kotlin
// build.gradle.kts
android {
    buildTypes {
        debug {
            buildConfigField("String", "API_BASE_URL", "\"https://dev-api.jugnu.app/api/v1/\"")
        }
        release {
            buildConfigField("String", "API_BASE_URL", "\"https://api.jugnu.app/api/v1/\"")
        }
    }
}
```

**Step 3:** Use remote config as primary source:
```kotlin
// RemoteConfig.kt
object RemoteConfig {
    private var _apiBaseUrl: String = BuildConfig.API_BASE_URL
    val apiBaseUrl: String get() = _apiBaseUrl
    
    fun updateApi(url: String) {
        if (url.startsWith("https://")) {
            _apiBaseUrl = url
        } else {
            Log.e("RemoteConfig", "Rejecting non-HTTPS URL: $url")
        }
    }
}
```

---

## 🔴 CRITICAL-004: Token Exposure in Logs

**Severity:** Critical | **Risk:** 8/10  
**Files:** Multiple files with `Log.d()` containing tokens  
**CWE:** CWE-532 (Insertion of Sensitive Information into Log File)

### Problem
```kotlin
// MyApp.kt:88
Log.d("RTM", "App ID='${BuildConfig.AGORA_APP_ID}' token=$token")

// RtmManager.kt
Log.d("RTM", "RTM login success")
```

Tokens logged in production:
- RTM tokens
- RTC tokens
- Session IDs
- API responses

### Impact
- **Logcat Exposure:** Tokens visible in logcat (adb)
- **Crash Reports:** Tokens included in crash logs
- **Third-party SDKs:** Analytics may capture logs
- **Account Compromise:** Stolen tokens allow unauthorized access

### Solution

**Step 1:** Create secure logging utility:
```kotlin
// core/utils/SecureLog.kt
object SecureLog {
    private const val TAG_PREFIX = "Jugnu"
    
    fun d(tag: String, message: String) {
        if (BuildConfig.DEBUG) {
            Log.d("$TAG_PREFIX:$tag", message)
        }
    }
    
    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (BuildConfig.DEBUG) {
            Log.e("$TAG_PREFIX:$tag", message, throwable)
        } else {
            // Send to crash reporting (without sensitive data)
            FirebaseCrashlytics.getInstance().log(message)
            throwable?.let { FirebaseCrashlytics.getInstance().recordException(it) }
        }
    }
    
    fun sensitive(tag: String, message: String) {
        // Never log sensitive data, even in debug
        if (BuildConfig.DEBUG) {
            Log.d("$TAG_PREFIX:$tag", "[REDACTED]")
        }
    }
}
```

**Step 2:** Replace all token logging:
```kotlin
// Before
Log.d("RTM", "token=$token")

// After
SecureLog.sensitive("RTM", "Token received")
```

**Step 3:** Add ProGuard rules to strip logs in release:
```proguard
# proguard-rules.pro
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
```

---

## 🟠 HIGH-001: Missing Certificate Pinning

**Severity:** High | **Risk:** 7/10  
**File:** `app/src/main/java/com/example/app/core/network/di/NetworkModule.kt`  
**CWE:** CWE-295 (Improper Certificate Validation)

### Problem
```kotlin
@Provides
@Singleton
fun provideOkHttpClient(...): OkHttpClient =
    OkHttpClient.Builder()
        .addInterceptor(...)
        .build()
```

No certificate pinning implemented, vulnerable to:
- SSL stripping attacks
- Forged certificates
- MITM even with HTTPS

### Impact
- **MITM Attacks:** Attacker with forged cert can intercept traffic
- **Data Theft:** All API data can be stolen
- **Session Hijacking:** Tokens intercepted

### Solution

**Step 1:** Get certificate pins:
```bash
# Get SHA-256 pin for your domain
openssl s_client -connect api.jugnu.app:443 | \
  openssl x509 -pubkey -noout | \
  openssl pkey -pubin -outform der | \
  openssl dgst -sha256 -binary | \
  base64
```

**Step 2:** Implement certificate pinning:
```kotlin
@Provides
@Singleton
fun provideCertificatePinner(): CertificatePinner {
    return CertificatePinner.Builder()
        .add(
            "api.jugnu.app",
            "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" // Primary cert
        )
        .add(
            "api.jugnu.app",
            "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=" // Backup cert
        )
        .build()
}

@Provides
@Singleton
fun provideOkHttpClient(
    certificatePinner: CertificatePinner,
    ...
): OkHttpClient =
    OkHttpClient.Builder()
        .certificatePinner(certificatePinner)
        .addInterceptor(...)
        .build()
```

**Step 3:** Add network security config:
```xml
<!-- res/xml/network_security_config.xml -->
<network-security-config>
    <domain-config>
        <domain includeSubdomains="true">api.jugnu.app</domain>
        <pin-set expiration="2027-01-01">
            <pin digest="SHA-256">AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=</pin>
            <pin digest="SHA-256">BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=</pin>
        </pin-set>
    </domain-config>
</network-security-config>
```

---

## 🟠 HIGH-002: Weak Session Management

**Severity:** High | **Risk:** 7/10  
**File:** `app/src/main/java/com/example/app/core/session/SessionManager.kt`  
**CWE:** CWE-384 (Session Fixation)

### Problem
```kotlin
object SessionManager {
    var userAccountId: Long = 0L
    var userRole: UserRole = UserRole.CUSTOMER
    var fcmToken: String? = null
    var sessionId: String = ""
}
```

Issues:
- Singleton object with mutable state
- Not thread-safe
- No session validation
- No expiration
- Lost on app restart

### Impact
- **Race Conditions:** Multiple threads can corrupt state
- **Session Loss:** User logged out unexpectedly
- **Security Risk:** No session timeout

### Solution
```kotlin
// core/session/SessionManager.kt
@Singleton
class SessionManager @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository,
    @ApplicationScope private val scope: CoroutineScope
) {
    private val _sessionState = MutableStateFlow<SessionState>(SessionState.Unauthenticated)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()
    
    private val sessionMutex = Mutex()
    
    data class SessionState(
        val accountId: Long = 0L,
        val sessionId: String = "",
        val role: UserRole = UserRole.CUSTOMER,
        val expiresAt: Long = 0L,
        val isValid: Boolean = false
    ) {
        companion object {
            val Unauthenticated = SessionState()
        }
    }
    
    suspend fun setSession(
        accountId: Long,
        sessionId: String,
        role: UserRole,
        ttlSeconds: Long = 86400 // 24 hours
    ) = sessionMutex.withLock {
        val expiresAt = System.currentTimeMillis() + (ttlSeconds * 1000)
        
        _sessionState.value = SessionState(
            accountId = accountId,
            sessionId = sessionId,
            role = role,
            expiresAt = expiresAt,
            isValid = true
        )
        
        // Persist
        userPreferencesRepository.saveSessionId(sessionId)
        userPreferencesRepository.saveUserPrefs(accountId, role)
        
        // Schedule expiration check
        scheduleExpirationCheck(ttlSeconds)
    }
    
    suspend fun validateSession(): Boolean = sessionMutex.withLock {
        val current = _sessionState.value
        if (!current.isValid) return false
        
        if (System.currentTimeMillis() > current.expiresAt) {
            clearSession()
            return false
        }
        
        return true
    }
    
    suspend fun clearSession() = sessionMutex.withLock {
        _sessionState.value = SessionState.Unauthenticated
        userPreferencesRepository.clearSession()
    }
    
    private fun scheduleExpirationCheck(ttlSeconds: Long) {
        scope.launch {
            delay(ttlSeconds * 1000)
            if (!validateSession()) {
                // Emit event to UI
                SessionEventBus.emit(SessionEvent.Expired)
            }
        }
    }
}
```

---

## 🟠 HIGH-003: No Input Validation on OTP

**Severity:** High | **Risk:** 6/10  
**File:** `app/src/main/java/com/example/app/feature/login/ui/OtpViewModel.kt`

### Problem
```kotlin
fun verifyOtp(phone: String, otp: String) {
    viewModelScope.launch {
        _otpVerifyState.value = OtpUiState.Loading
        val result = verifyOtpUseCase(phone, otp, fcmToken)
        // No validation before API call
    }
}
```

### Solution
```kotlin
fun verifyOtp(phone: String, otp: String) {
    viewModelScope.launch {
        // Validate inputs
        if (!isValidPhone(phone)) {
            _otpVerifyState.value = OtpUiState.Error("Invalid phone number")
            return@launch
        }
        
        if (!isValidOtp(otp)) {
            _otpVerifyState.value = OtpUiState.Error("OTP must be 6 digits")
            return@launch
        }
        
        _otpVerifyState.value = OtpUiState.Loading
        val result = verifyOtpUseCase(phone, otp, fcmToken)
        // ...
    }
}

private fun isValidPhone(phone: String): Boolean {
    return phone.matches(Regex("^[0-9]{10}$"))
}

private fun isValidOtp(otp: String): Boolean {
    return otp.matches(Regex("^[0-9]{6}$"))
}
```

---

## 🟠 HIGH-004: Unencrypted WebSocket Connection

**Severity:** High | **Risk:** 6/10  
**File:** `app/src/main/java/com/example/app/core/websocket/PresenceWebSocketManager.kt:67`

### Problem
```kotlin
private fun buildWsUrl(): String {
    val base = (RemoteConfig.wsBaseUrl ?: RemoteConfig.apiBaseUrl)
        .replace("https://", "wss://")
        .replace("http://", "ws://") // ❌ Allows ws://
    return base + "/" + AppConstants.WS_PRESENCE_PATH
}
```

### Solution
```kotlin
private fun buildWsUrl(): String {
    val base = (RemoteConfig.wsBaseUrl ?: RemoteConfig.apiBaseUrl)
        .trimEnd('/')
    
    // Only allow HTTPS/WSS
    val secureBase = when {
        base.startsWith("https://") -> base.replace("https://", "wss://")
        base.startsWith("wss://") -> base
        else -> {
            Log.e("WebSocket", "Rejecting insecure URL: $base")
            throw SecurityException("WebSocket requires secure connection (wss://)")
        }
    }
    
    return "$secureBase/${AppConstants.WS_PRESENCE_PATH.trimStart('/')}"
}
```

---

**[Continue to Performance Issues →](./02-PERFORMANCE-ISSUES.md)**
