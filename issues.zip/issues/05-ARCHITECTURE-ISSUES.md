# 🏗️ ARCHITECTURE & DESIGN ISSUES

**Category:** Architecture  
**Total Issues:** 5 (1 High, 4 Medium)  
**Priority:** MEDIUM - Fix Within 1 Month

---

## 🟠 HIGH-010: Singleton Anti-Pattern for Session Management

**Severity:** High | **Risk:** 6/10  
**File:** `app/src/main/java/com/example/app/core/session/SessionManager.kt`  
**Impact:** Thread safety issues, testing difficulties

### Problem
```kotlin
object SessionManager {
    var userAccountId: Long = 0L
    var userRole: UserRole = UserRole.CUSTOMER
    var fcmToken: String? = null
    var sessionId: String = ""
}
```

**Issues:**
- Object singleton with mutable state
- Not thread-safe
- Cannot be mocked for testing
- Global mutable state is anti-pattern
- No lifecycle management

### Impact
- **Race Conditions:** Multiple threads can corrupt state
- **Testing:** Cannot inject mock for unit tests
- **Maintenance:** Hard to track state changes
- **Memory:** Never garbage collected

### Solution

Already provided in Security Issues (HIGH-002). Here's the complete refactored version:

```kotlin
// core/session/SessionManager.kt
@Singleton
class SessionManager @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository,
    @ApplicationScope private val scope: CoroutineScope
) {
    private val _sessionState = MutableStateFlow<SessionState>(SessionState.Unauthenticated)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()
    
    private val sessionMutex = Mutex()
    
    data class SessionState(
        val accountId: Long = 0L,
        val sessionId: String = "",
        val role: UserRole = UserRole.CUSTOMER,
        val fcmToken: String? = null,
        val expiresAt: Long = 0L,
        val isValid: Boolean = false
    ) {
        companion object {
            val Unauthenticated = SessionState()
        }
    }
    
    // Thread-safe operations with mutex
    suspend fun setSession(...) = sessionMutex.withLock { ... }
    suspend fun validateSession(): Boolean = sessionMutex.withLock { ... }
    suspend fun clearSession() = sessionMutex.withLock { ... }
}

// Update all usages
class SomeViewModel @Inject constructor(
    private val sessionManager: SessionManager // Injected, not global
) : ViewModel() {
    
    init {
        viewModelScope.launch {
            sessionManager.sessionState.collect { state ->
                // React to session changes
            }
        }
    }
}
```

---

## 🟡 MEDIUM-014: No Separation of Concerns in App Initialization

**Severity:** Medium | **Risk:** 5/10  
**File:** `app/src/main/java/com/example/app/MyApp.kt`  
**Impact:** Tight coupling, hard to test

### Problem
```kotlin
@HiltAndroidApp
class MyApp : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // ❌ Too many responsibilities
        ProcessLifecycleOwner.get().lifecycle.addObserver(appForegroundTracker)
        
        appScope.launch(Dispatchers.IO) {
            // Config loading
            ConfigLoader.refresh(remoteConfigRepo)
        }
        
        tokenManager.start()
        restoreSessionId()
        observeUserSession()
        eventObserver.toString()
    }
}
```

**Issues:**
- Application class doing too much
- Hard to test individual components
- No clear initialization order
- Difficult to add/remove features

### Impact
- **Maintenance:** Hard to modify initialization
- **Testing:** Cannot test components in isolation
- **Bugs:** Unclear dependencies between initializers

### Solution

**Step 1: Create initialization orchestrator**
```kotlin
// core/init/AppInitializer.kt
interface Initializer {
    val priority: Int // Lower = earlier
    suspend fun initialize()
}

@Singleton
class AppInitializerOrchestrator @Inject constructor(
    private val initializers: Set<@JvmSuppressWildcards Initializer>
) {
    suspend fun initialize() {
        initializers
            .sortedBy { it.priority }
            .forEach { initializer ->
                try {
                    initializer.initialize()
                    Log.d("AppInit", "${initializer::class.simpleName} initialized")
                } catch (e: Exception) {
                    Log.e("AppInit", "${initializer::class.simpleName} failed", e)
                    // Decide if failure is critical
                }
            }
    }
}

// Individual initializers
@Singleton
class RemoteConfigInitializer @Inject constructor(
    private val remoteConfigRepo: RemoteConfigRepository,
    private val configLoader: ConfigLoader
) : Initializer {
    override val priority = 1 // High priority
    
    override suspend fun initialize() {
        if (AppConstants.USE_DEFAULT_URL) {
            RemoteConfig.updateApi(AppConstants.DEFAULT_BASE_URL)
        } else {
            val cached = remoteConfigRepo.loadApiBaseUrl()
            if (cached != null) RemoteConfig.updateApi(cached)
            configLoader.refresh(remoteConfigRepo)
        }
    }
}

@Singleton
class SessionInitializer @Inject constructor(
    private val userSession: UserSession,
    private val sessionManager: SessionManager
) : Initializer {
    override val priority = 2
    
    override suspend fun initialize() {
        val sessionId = userSession.sessionId
        if (sessionId.isNotEmpty()) {
            // Restore session
        }
    }
}

@Singleton
class RtmInitializer @Inject constructor(
    private val userSession: UserSession,
    private val apiRepository: ApiRepository,
    @ApplicationContext private val context: Context,
    @ApplicationScope private val scope: CoroutineScope
) : Initializer {
    override val priority = 3
    
    override suspend fun initialize() {
        userSession.sessionFlow.collect { (accountId, _) ->
            if (accountId > 0) {
                initializeRtm(accountId)
            }
        }
    }
    
    private suspend fun initializeRtm(accountId: Long) {
        // RTM initialization logic
    }
}

// Provide initializers set
@Module
@InstallIn(SingletonComponent::class)
abstract class InitializerModule {
    
    @Binds
    @IntoSet
    abstract fun bindRemoteConfigInitializer(
        impl: RemoteConfigInitializer
    ): Initializer
    
    @Binds
    @IntoSet
    abstract fun bindSessionInitializer(
        impl: SessionInitializer
    ): Initializer
    
    @Binds
    @IntoSet
    abstract fun bindRtmInitializer(
        impl: RtmInitializer
    ): Initializer
}
```

**Step 2: Simplify Application class**
```kotlin
@HiltAndroidApp
class MyApp : Application() {
    
    @Inject
    lateinit var appForegroundTracker: AppForegroundTracker
    
    @Inject
    lateinit var appInitializer: AppInitializerOrchestrator
    
    @Inject
    @ApplicationScope
    lateinit var appScope: CoroutineScope
    
    override fun onCreate() {
        super.onCreate()
        
        // Observe lifecycle
        ProcessLifecycleOwner.get()
            .lifecycle
            .addObserver(appForegroundTracker)
        
        // Initialize all components
        appScope.launch {
            appInitializer.initialize()
        }
    }
}
```

---

## 🟡 MEDIUM-015: Bidirectional Dependencies

**Severity:** Medium | **Risk:** 4/10  
**Files:** `SessionManager.kt`, `UserSession.kt`  
**Impact:** Circular dependencies, hard to test

### Problem
```kotlin
// SessionManager uses UserSession
object SessionManager {
    var userAccountId: Long = 0L
}

// UserSession uses SessionManager
class UserSession {
    val sessionId: String
        get() = SessionManager.sessionId
}
```

### Solution

**Consolidate into single source of truth:**
```kotlin
// core/session/SessionRepository.kt
@Singleton
class SessionRepository @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository
) {
    private val _sessionState = MutableStateFlow<SessionData?>(null)
    val sessionState: StateFlow<SessionData?> = _sessionState.asStateFlow()
    
    data class SessionData(
        val accountId: Long,
        val sessionId: String,
        val role: UserRole,
        val fcmToken: String?,
        val createdAt: Long,
        val expiresAt: Long
    ) {
        fun isValid(): Boolean {
            return System.currentTimeMillis() < expiresAt
        }
    }
    
    suspend fun saveSession(data: SessionData) {
        _sessionState.value = data
        userPreferencesRepository.saveSessionId(data.sessionId)
        userPreferencesRepository.saveUserPrefs(data.accountId, data.role)
    }
    
    suspend fun loadSession(): SessionData? {
        // Load from preferences
        return _sessionState.value
    }
    
    suspend fun clearSession() {
        _sessionState.value = null
        userPreferencesRepository.clearSession()
    }
}

// Remove SessionManager and UserSession, use SessionRepository everywhere
```

---

## 🟡 MEDIUM-016: No Error Boundary Pattern

**Severity:** Medium | **Risk:** 4/10  
**Files:** All ViewModels  
**Impact:** Inconsistent error handling

### Problem
```kotlin
// Each ViewModel handles errors differently
class OtpViewModel {
    fun verifyOtp() {
        viewModelScope.launch {
            when (val result = verifyOtpUseCase()) {
                is ApiResult.Error -> {
                    _state.value = OtpUiState.Error(result.message ?: "Error")
                }
            }
        }
    }
}

class ListenerViewModel {
    fun loadListeners() {
        viewModelScope.launch {
            when (val result = listenerRepository.getListeners()) {
                is ApiResult.Error -> {
                    // Different error handling
                    _error.value = result.message
                }
            }
        }
    }
}
```

### Solution

**Create centralized error handler:**
```kotlin
// core/error/ErrorHandler.kt
@Singleton
class ErrorHandler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    fun handle(error: Throwable): ErrorState {
        return when (error) {
            is IOException -> ErrorState.NetworkError(
                message = "Network connection failed. Please check your internet.",
                canRetry = true
            )
            is HttpException -> handleHttpError(error)
            is SerializationException -> ErrorState.UnknownError(
                message = "Data format error. Please update the app."
            )
            else -> ErrorState.UnknownError(
                message = error.message ?: "An unexpected error occurred"
            )
        }
    }
    
    private fun handleHttpError(error: HttpException): ErrorState {
        return when (error.code()) {
            401 -> ErrorState.AuthError("Session expired. Please login again.")
            403 -> ErrorState.AuthError("Access denied.")
            404 -> ErrorState.NotFoundError("Resource not found.")
            429 -> ErrorState.RateLimitError("Too many requests. Please try again later.")
            in 500..599 -> ErrorState.ServerError(
                code = error.code(),
                message = "Server error. Please try again later."
            )
            else -> ErrorState.UnknownError(
                message = "Request failed (${error.code()})"
            )
        }
    }
}

// Base ViewModel with error handling
abstract class BaseViewModel(
    private val errorHandler: ErrorHandler
) : ViewModel() {
    
    protected val _error = MutableStateFlow<ErrorState?>(null)
    val error: StateFlow<ErrorState?> = _error.asStateFlow()
    
    protected suspend fun <T> handleApiCall(
        call: suspend () -> ApiResult<T>
    ): T? {
        return when (val result = call()) {
            is ApiResult.Success -> result.data
            is ApiResult.Error -> {
                _error.value = result.exception?.let { errorHandler.handle(it) }
                    ?: ErrorState.UnknownError(result.message ?: "Unknown error")
                null
            }
        }
    }
    
    fun clearError() {
        _error.value = null
    }
}

// Usage in ViewModels
class OtpViewModel @Inject constructor(
    private val verifyOtpUseCase: VerifyOtpUseCase,
    errorHandler: ErrorHandler
) : BaseViewModel(errorHandler) {
    
    fun verifyOtp(phone: String, otp: String) {
        viewModelScope.launch {
            _otpVerifyState.value = OtpUiState.Loading
            
            val result = handleApiCall {
                verifyOtpUseCase(phone, otp)
            }
            
            _otpVerifyState.value = if (result != null) {
                OtpUiState.Success(result)
            } else {
                OtpUiState.Idle // Error already set in base class
            }
        }
    }
}
```

---

## 🟡 MEDIUM-017: Tight Coupling to Agora SDK

**Severity:** Medium | **Risk:** 4/10  
**Files:** `AgoraVideoRtcManager.kt`, `AgoraVoiceRtcManager.kt`  
**Impact:** Hard to test, switch providers

### Problem
```kotlin
// Direct Agora SDK usage everywhere
class AgoraVoiceRtcManager {
    private var rtcEngine: RtcEngine? = null
    
    fun join(callId: String, channel: String, token: String?) {
        rtcEngine?.joinChannel(token, channel, null, 0)
    }
}
```

### Solution

**Create abstraction layer:**
```kotlin
// core/rtc/RtcProvider.kt
interface RtcProvider {
    suspend fun initialize(config: RtcConfig): Result<Unit>
    suspend fun joinChannel(channel: String, token: String): Result<Unit>
    suspend fun leaveChannel(): Result<Unit>
    fun muteLocalAudio(mute: Boolean)
    fun enableSpeaker(enable: Boolean)
    val events: Flow<RtcEvent>
}

data class RtcConfig(
    val appId: String,
    val userId: String,
    val channelProfile: ChannelProfile
)

enum class ChannelProfile {
    COMMUNICATION,
    LIVE_BROADCASTING
}

// Agora implementation
@Singleton
class AgoraRtcProvider @Inject constructor(
    @ApplicationContext private val context: Context
) : RtcProvider {
    
    private var rtcEngine: RtcEngine? = null
    private val _events = MutableSharedFlow<RtcEvent>()
    override val events = _events.asSharedFlow()
    
    override suspend fun initialize(config: RtcConfig): Result<Unit> {
        return try {
            val engine = RtcEngine.create(
                context,
                config.appId,
                createEventHandler()
            )
            rtcEngine = engine
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Implement other methods...
}

// Can easily swap to different provider
@Singleton
class TwilioRtcProvider @Inject constructor() : RtcProvider {
    // Twilio implementation
}

// Provide based on configuration
@Module
@InstallIn(SingletonComponent::class)
object RtcModule {
    
    @Provides
    @Singleton
    fun provideRtcProvider(
        agoraProvider: AgoraRtcProvider
    ): RtcProvider {
        // Can switch based on BuildConfig or remote config
        return agoraProvider
    }
}
```

---

**[← Back to Code Quality Issues](./04-CODE-QUALITY-ISSUES.md) | [Continue to Error Handling Issues →](./06-ERROR-HANDLING-ISSUES.md)**
