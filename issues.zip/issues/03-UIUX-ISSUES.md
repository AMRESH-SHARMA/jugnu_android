# 🎨 UI/UX & ACCESSIBILITY ISSUES

**Category:** User Experience  
**Total Issues:** 5 (4 Medium, 1 Low)  
**Priority:** MEDIUM - Fix Within 1 Month

---

## 🟡 MEDIUM-007: Missing Loading States During Critical Operations

**Severity:** Medium | **Risk:** 5/10  
**Files:** Multiple screens (OTP, Login, Call screens)  
**Impact:** User confusion, duplicate submissions

### Problem

**OTP Screen:**
```kotlin
// OtpViewModel.kt has loading state but UI doesn't show it properly
fun verifyOtp(phone: String, otp: String) {
    viewModelScope.launch {
        _otpVerifyState.value = OtpUiState.Loading
        // User doesn't see loading indicator
    }
}
```

**Call Initiation:**
```kotlin
// No loading state when initiating call
fun initiateCall(listenerId: Long) {
    viewModelScope.launch {
        // User can tap multiple times
        val result = callRepository.initiateCall(listenerId)
    }
}
```

### Impact
- **User Confusion:** Users don't know if action is processing
- **Duplicate Requests:** Users tap button multiple times
- **Poor UX:** App feels unresponsive

### Solution

**Step 1: Create reusable loading component**
```kotlin
// feature/components/LoadingButton.kt
@Composable
fun LoadingButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.buttonColors()
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled && !isLoading,
        colors = colors
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = colors.contentColor,
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(text)
    }
}
```

**Step 2: Update OTP Screen**
```kotlin
// feature/login/ui/OtpScreen.kt
@Composable
fun OtpScreen(
    navController: NavController,
    viewModel: OtpViewModel = hiltViewModel()
) {
    val verifyState by viewModel.otpVerifyState.collectAsState()
    val isLoading = verifyState is OtpUiState.Loading
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        // OTP Input
        OtpInputField(
            value = otpValue,
            onValueChange = { otpValue = it },
            enabled = !isLoading
        )
        
        Spacer(Modifier.height(24.dp))
        
        // Loading Button
        LoadingButton(
            text = "Verify OTP",
            onClick = { viewModel.verifyOtp(phone, otpValue) },
            isLoading = isLoading,
            modifier = Modifier.fillMaxWidth()
        )
        
        // Show error if any
        if (verifyState is OtpUiState.Error) {
            Text(
                text = (verifyState as OtpUiState.Error).message,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
```

**Step 3: Add loading overlay for full-screen operations**
```kotlin
// feature/components/LoadingOverlay.kt
@Composable
fun LoadingOverlay(
    isLoading: Boolean,
    message: String = "Loading...",
    content: @Composable () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        content()
        
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(enabled = false) { },
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(16.dp))
                        Text(message)
                    }
                }
            }
        }
    }
}

// Usage in screens
@Composable
fun CallScreen(viewModel: CallViewModel = hiltViewModel()) {
    val isInitiating by viewModel.isInitiatingCall.collectAsState()
    
    LoadingOverlay(
        isLoading = isInitiating,
        message = "Connecting call..."
    ) {
        // Screen content
    }
}
```

---

## 🟡 MEDIUM-008: Poor Error Recovery UI

**Severity:** Medium | **Risk:** 5/10  
**Files:** `ErrorScreens.kt`, All ViewModels  
**Impact:** Users don't understand errors, can't recover

### Problem

**Current Error Screens:**
```kotlin
// ErrorScreens.kt
@Composable
fun NoInternetScreen(onRetry: () -> Unit) {
    // Generic error message
    Text("Please check your internet connection and try again.")
}
```

**Issues:**
- No specific error details
- No actionable steps
- No error codes for support
- No offline mode

### Impact
- **User Frustration:** Users don't know what to do
- **Support Burden:** Users can't report specific errors
- **Poor UX:** No graceful degradation

### Solution

**Step 1: Enhanced error state**
```kotlin
// core/ui/ErrorState.kt
sealed class ErrorState {
    data class NetworkError(
        val code: Int? = null,
        val message: String,
        val canRetry: Boolean = true,
        val timestamp: Long = System.currentTimeMillis()
    ) : ErrorState()
    
    data class ServerError(
        val code: Int,
        val message: String,
        val errorId: String? = null
    ) : ErrorState()
    
    data class ValidationError(
        val field: String,
        val message: String
    ) : ErrorState()
    
    data class UnknownError(
        val message: String,
        val throwable: Throwable? = null
    ) : ErrorState()
}
```

**Step 2: Comprehensive error screen**
```kotlin
// feature/components/ErrorScreen.kt
@Composable
fun ErrorScreen(
    error: ErrorState,
    onRetry: () -> Unit,
    onContactSupport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Error Icon
        Icon(
            imageVector = when (error) {
                is ErrorState.NetworkError -> Icons.Default.WifiOff
                is ErrorState.ServerError -> Icons.Default.CloudOff
                else -> Icons.Default.Error
            },
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = MaterialTheme.colorScheme.error
        )
        
        Spacer(Modifier.height(24.dp))
        
        // Error Title
        Text(
            text = when (error) {
                is ErrorState.NetworkError -> "Connection Problem"
                is ErrorState.ServerError -> "Server Error"
                is ErrorState.ValidationError -> "Invalid Input"
                is ErrorState.UnknownError -> "Something Went Wrong"
            },
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(Modifier.height(16.dp))
        
        // Error Message
        Text(
            text = error.getMessage(),
            textAlign = TextAlign.Center,
            color = Color.Gray
        )
        
        // Error Details (expandable)
        var showDetails by remember { mutableStateOf(false) }
        
        if (error is ErrorState.ServerError && error.errorId != null) {
            Spacer(Modifier.height(16.dp))
            
            TextButton(onClick = { showDetails = !showDetails }) {
                Text(if (showDetails) "Hide Details" else "Show Details")
            }
            
            if (showDetails) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFF5F5F5)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Error Code: ${error.code}", fontSize = 12.sp)
                        Text("Error ID: ${error.errorId}", fontSize = 12.sp)
                        Text(
                            "Time: ${formatTimestamp(System.currentTimeMillis())}",
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
        
        Spacer(Modifier.height(32.dp))
        
        // Action Buttons
        if (error.canRetry()) {
            Button(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Try Again")
            }
        }
        
        Spacer(Modifier.height(12.dp))
        
        OutlinedButton(
            onClick = onContactSupport,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Support, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Contact Support")
        }
        
        // Helpful Tips
        Spacer(Modifier.height(24.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFF0F9FF)
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "💡 Helpful Tips",
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                when (error) {
                    is ErrorState.NetworkError -> {
                        Text("• Check your WiFi or mobile data", fontSize = 14.sp)
                        Text("• Try switching networks", fontSize = 14.sp)
                        Text("• Restart your device", fontSize = 14.sp)
                    }
                    is ErrorState.ServerError -> {
                        Text("• Our team has been notified", fontSize = 14.sp)
                        Text("• Try again in a few minutes", fontSize = 14.sp)
                        Text("• Check our status page", fontSize = 14.sp)
                    }
                    else -> {
                        Text("• Contact support if issue persists", fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

private fun ErrorState.getMessage(): String = when (this) {
    is ErrorState.NetworkError -> message
    is ErrorState.ServerError -> message
    is ErrorState.ValidationError -> message
    is ErrorState.UnknownError -> message
}

private fun ErrorState.canRetry(): Boolean = when (this) {
    is ErrorState.NetworkError -> canRetry
    is ErrorState.ServerError -> true
    else -> false
}
```

---

## 🟡 MEDIUM-009: Inconsistent Navigation State Management

**Severity:** Medium | **Risk:** 4/10  
**Files:** `AppNavGraph.kt`, `MainActivity.kt`  
**Impact:** Lost navigation state on rotation

### Problem
```kotlin
// AppNavGraph.kt
@Composable
fun AppNavGraph() {
    val navController = rememberNavController()
    // State lost on configuration change
}
```

### Impact
- **Poor UX:** User loses place in app during rotation
- **Data Loss:** Form inputs lost
- **Frustration:** Have to navigate back

### Solution
```kotlin
// feature/navigation/ui/AppNavGraph.kt
@Composable
fun AppNavGraph() {
    // Save and restore navigation state
    val navController = rememberSaveable(
        saver = NavControllerSaver()
    ) {
        NavHostController(LocalContext.current)
    }
    
    // Rest of navigation setup
}

// Custom saver for NavController
class NavControllerSaver : Saver<NavHostController, Bundle> {
    override fun restore(value: Bundle): NavHostController {
        val context = value.getParcelable<Context>("context")!!
        val controller = NavHostController(context)
        controller.restoreState(value.getBundle("state"))
        return controller
    }
    
    override fun SaverScope.save(value: NavHostController): Bundle {
        return Bundle().apply {
            putParcelable("context", value.context as? Parcelable)
            putBundle("state", value.saveState())
        }
    }
}

// For ViewModels, use SavedStateHandle
class OtpViewModel @Inject constructor(
    private val savedStateHandle: SavedStateHandle,
    ...
) : ViewModel() {
    
    private val _otpValue = savedStateHandle.getStateFlow("otp_value", "")
    val otpValue: StateFlow<String> = _otpValue
    
    fun updateOtp(value: String) {
        savedStateHandle["otp_value"] = value
    }
}
```

---

## 🟡 MEDIUM-010: No Accessibility Support

**Severity:** Medium | **Risk:** 4/10  
**Files:** All Compose screens  
**Impact:** App unusable for visually impaired users

### Problem
```kotlin
// SelectUserRoleScreen.kt
Icon(
    imageVector = Icons.Default.Headset,
    contentDescription = null, // ❌ No description
    modifier = Modifier.size(64.dp)
)

Button(onClick = { /* ... */ }) {
    Text("Continue") // ❌ No semantic info
}
```

### Impact
- **Accessibility:** Screen readers can't describe UI
- **Compliance:** Fails WCAG guidelines
- **Legal:** ADA compliance issues

### Solution

**Step 1: Add content descriptions**
```kotlin
// SelectUserRoleScreen.kt
Icon(
    imageVector = Icons.Default.Headset,
    contentDescription = "Jugnu app logo",
    modifier = Modifier.size(64.dp)
)

OutlinedTextField(
    value = accountId,
    onValueChange = { accountId = it },
    modifier = Modifier
        .fillMaxWidth()
        .semantics {
            contentDescription = "Enter your account ID number"
            testTag = "account_id_input"
        },
    placeholder = { Text("Enter your account ID") }
)

Button(
    onClick = { selectedRole = UserRole.CUSTOMER },
    modifier = Modifier.semantics {
        contentDescription = "Select customer role to find listeners"
        role = Role.Button
    }
) {
    Text("Customer")
}
```

**Step 2: Add semantic properties**
```kotlin
// RoleCard.kt
@Composable
fun RoleCard(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .height(140.dp)
            .semantics(mergeDescendants = true) {
                contentDescription = if (isSelected) {
                    "$title role selected"
                } else {
                    "Select $title role"
                }
                role = Role.RadioButton
                stateDescription = if (isSelected) "Selected" else "Not selected"
                if (enabled) {
                    onClick(label = "Select $title") {
                        onClick()
                        true
                    }
                }
            }
            .clickable(enabled = enabled) { onClick() }
    ) {
        // Card content
    }
}
```

**Step 3: Add focus management**
```kotlin
// OtpScreen.kt
@Composable
fun OtpScreen(...) {
    val focusRequester = remember { FocusRequester() }
    
    LaunchedEffect(Unit) {
        // Auto-focus OTP input
        focusRequester.requestFocus()
    }
    
    OtpInputField(
        modifier = Modifier.focusRequester(focusRequester),
        // ...
    )
}
```

**Step 4: Add minimum touch targets**
```kotlin
// Ensure all interactive elements are at least 48dp
Button(
    onClick = { /* ... */ },
    modifier = Modifier
        .fillMaxWidth()
        .heightIn(min = 48.dp) // Minimum touch target
) {
    Text("Continue")
}
```

---

## 🟢 LOW-001: Missing User Feedback for Actions

**Severity:** Low | **Risk:** 3/10  
**Files:** Multiple screens  
**Impact:** Users unsure if action succeeded

### Problem
- No success messages after actions
- No haptic feedback
- No visual confirmation

### Solution
```kotlin
// core/ui/FeedbackManager.kt
@Singleton
class FeedbackManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        vibratorManager.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    
    fun success() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        }
    }
    
    fun error() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createWaveform(
                    longArrayOf(0, 50, 50, 50),
                    -1
                )
            )
        }
    }
}

// Usage in ViewModels
class OtpViewModel @Inject constructor(
    private val feedbackManager: FeedbackManager,
    ...
) : ViewModel() {
    
    fun verifyOtp(phone: String, otp: String) {
        viewModelScope.launch {
            when (val result = verifyOtpUseCase(phone, otp)) {
                is ApiResult.Success -> {
                    feedbackManager.success()
                    _otpVerifyState.value = OtpUiState.Success(result.data)
                }
                is ApiResult.Error -> {
                    feedbackManager.error()
                    _otpVerifyState.value = OtpUiState.Error(result.message)
                }
            }
        }
    }
}

// Add snackbar for success messages
@Composable
fun OtpScreen(...) {
    val snackbarHostState = remember { SnackbarHostState() }
    val verifyState by viewModel.otpVerifyState.collectAsState()
    
    LaunchedEffect(verifyState) {
        if (verifyState is OtpUiState.Success) {
            snackbarHostState.showSnackbar(
                message = "✓ Verification successful!",
                duration = SnackbarDuration.Short
            )
        }
    }
    
    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) {
        // Screen content
    }
}
```

---

**[← Back to Performance Issues](./02-PERFORMANCE-ISSUES.md) | [Continue to Code Quality Issues →](./04-CODE-QUALITY-ISSUES.md)**
