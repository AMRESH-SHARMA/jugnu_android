# 🐛 CODE QUALITY & BUGS

**Category:** Code Quality  
**Total Issues:** 7 (3 High, 3 Medium, 1 Low)  
**Priority:** HIGH - Fix Within 1 Week

---

## 🟠 HIGH-007: Race Condition in RTM Initialization

**Severity:** High | **Risk:** 7/10  
**File:** `app/src/main/java/com/example/app/MyApp.kt:72`  
**Impact:** Multiple RTM instances, resource leaks

### Problem
```kotlin
private val rtmInitialized = AtomicBoolean(false)

private fun observeUserSession() {
    appScope.launch(Dispatchers.IO) {
        userSession.sessionFlow.collect { (accountId, _) ->
            if (accountId > 0) {
                presenceWebSocketManager.connect()
                
                // ❌ Race condition here
                if (rtmInitialized.compareAndSet(false, true)) {
                    initAndLoginRtm(accountId)
                }
            }
        }
    }
}

private suspend fun initAndLoginRtm(accountId: Long) {
    // This is async, but flag is already set to true
    when (val result = apiRepository.getRtmToken(accountId)) {
        is ApiResult.Success -> {
            RtmManager.init(...)
            RtmManager.login(token)
        }
    }
}
```

**Issues:**
- Flag set before async operation completes
- If session changes rapidly, multiple init attempts possible
- No synchronization between check and init

### Impact
- **Resource Leak:** Multiple RTM clients created
- **Crashes:** Agora SDK doesn't support multiple instances
- **Memory:** Leaked connections

### Solution
```kotlin
// MyApp.kt
@HiltAndroidApp
class MyApp : Application() {
    
    private val rtmInitMutex = Mutex()
    private var rtmInitialized = false
    
    private fun observeUserSession() {
        appScope.launch(Dispatchers.IO) {
            userSession.sessionFlow.collect { (accountId, _) ->
                if (accountId > 0) {
                    presenceWebSocketManager.connect()
                    initializeRtmIfNeeded(accountId)
                } else {
                    presenceWebSocketManager.disconnect()
                    cleanupRtm()
                }
            }
        }
    }
    
    private suspend fun initializeRtmIfNeeded(accountId: Long) {
        rtmInitMutex.withLock {
            if (rtmInitialized) {
                Log.d("RTM", "Already initialized, skipping")
                return
            }
            
            try {
                when (val result = apiRepository.getRtmToken(accountId)) {
                    is ApiResult.Success -> {
                        val token = result.data
                        
                        RtmManager.init(
                            context = applicationContext,
                            appId = BuildConfig.AGORA_APP_ID,
                            userId = accountId.toString(),
                            listener = RtmEventListenerImpl(appScope),
                            appScope = appScope
                        )
                        
                        RtmManager.login(token)
                        rtmInitialized = true
                        
                        Log.d("RTM", "RTM initialized successfully")
                    }
                    is ApiResult.Error -> {
                        Log.e("RTM", "Failed to get RTM token: ${result.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e("RTM", "RTM initialization failed", e)
                rtmInitialized = false
            }
        }
    }
    
    private suspend fun cleanupRtm() {
        rtmInitMutex.withLock {
            if (rtmInitialized) {
                RtmManager.logout()
                rtmInitialized = false
                Log.d("RTM", "RTM cleaned up")
            }
        }
    }
}
```

---

## 🟠 HIGH-008: Unhandled JSON Parsing Exceptions

**Severity:** High | **Risk:** 6/10  
**File:** `app/src/main/java/com/example/app/core/rtm/RtmEventListenerImpl.kt:38`  
**Impact:** Silent call event failures

### Problem
```kotlin
override fun onMessageEvent(event: MessageEvent) {
    try {
        val signal = json.decodeFromString<CallSignalPayload>(jsonPayload)
        
        scope.launch {
            when (signal.event) {
                AppConstants.EVENT_INCOMING_CALL -> {
                    CallEventBus.emit(CallEvent.Incoming(...))
                }
                // ...
            }
        }
    } catch (e: Exception) {
        Log.e("RTM", "Failed to decode RTM payload", e)
        // ❌ Error logged but not handled
    }
}
```

**Issues:**
- Parsing failures silently ignored
- User doesn't know call was missed
- No retry mechanism
- No error reporting

### Impact
- **Missed Calls:** Users don't receive incoming calls
- **Silent Failures:** No indication of problem
- **Poor UX:** Unreliable call system

### Solution
```kotlin
// core/rtm/RtmEventListenerImpl.kt
class RtmEventListenerImpl(
    private val scope: CoroutineScope
) : RtmEventListener {
    
    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
    }
    
    private val parseErrorCount = AtomicInteger(0)
    
    override fun onMessageEvent(event: MessageEvent) {
        val rtmMessage = event.message
        val raw = rtmMessage.toString()
        
        try {
            val jsonPayload = extractJsonPayload(raw)
            val signal = json.decodeFromString<CallSignalPayload>(jsonPayload)
            
            // Reset error count on success
            parseErrorCount.set(0)
            
            handleCallSignal(signal)
            
        } catch (e: SerializationException) {
            handleParseError("JSON parsing failed", e, raw)
        } catch (e: IllegalArgumentException) {
            handleParseError("Invalid payload format", e, raw)
        } catch (e: Exception) {
            handleParseError("Unexpected error", e, raw)
        }
    }
    
    private fun extractJsonPayload(raw: String): String {
        return try {
            raw.substringAfter("message: ")
                .substringBefore(", data:")
        } catch (e: Exception) {
            throw IllegalArgumentException("Failed to extract JSON from RTM message", e)
        }
    }
    
    private fun handleCallSignal(signal: CallSignalPayload) {
        scope.launch {
            try {
                when (signal.event) {
                    AppConstants.EVENT_INCOMING_CALL -> {
                        CallEventBus.emit(
                            CallEvent.Incoming(
                                callId = signal.callId,
                                callType = signal.callType 
                                    ?: throw IllegalStateException("Call type missing"),
                                callerAccountId = signal.callerAccountId 
                                    ?: throw IllegalStateException("Caller ID missing"),
                                calleeAccountId = signal.calleeAccountId 
                                    ?: throw IllegalStateException("Callee ID missing"),
                                channel = signal.channel
                            )
                        )
                    }
                    // Handle other events...
                }
            } catch (e: Exception) {
                Log.e("RTM", "Failed to handle call signal", e)
                // Emit error event to UI
                CallEventBus.emit(CallEvent.Error(signal.callId, e.message))
            }
        }
    }
    
    private fun handleParseError(message: String, error: Exception, raw: String) {
        val errorCount = parseErrorCount.incrementAndGet()
        
        Log.e("RTM", "$message (count: $errorCount)", error)
        Log.e("RTM", "Raw message: $raw")
        
        // Send to crash reporting
        FirebaseCrashlytics.getInstance().apply {
            log("RTM parse error count: $errorCount")
            log("Raw RTM message: ${raw.take(500)}") // Truncate for privacy
            recordException(error)
        }
        
        // If too many errors, emit system error
        if (errorCount >= 5) {
            scope.launch {
                UiEventBus.emit(
                    UiEvent.ShowSnackbar(
                        "Connection issues detected. Please restart the app."
                    )
                )
            }
        }
    }
}

// Add error event type
sealed class CallEvent {
    // ... existing events
    data class Error(val callId: String, val message: String?) : CallEvent()
}
```

---

## 🟠 HIGH-009: Null Safety Issues in CallManager

**Severity:** High | **Risk:** 6/10  
**File:** `app/src/main/java/com/example/app/core/call/CallManager.kt`  
**Impact:** Potential crashes during call transitions

### Problem
```kotlin
fun onAccepted(event: CallEvent.Accepted) {
    val current = CallStore.current() ?: return // ❌ Silent failure
    
    val newChannel = event.channel ?: current.channel
    val newToken = event.rtcToken.ifBlank { current.rtcToken }
    
    // What if current.channel is also null?
    CallStore.update {
        it.copy(
            status = CallStatus.CONNECTING,
            channel = newChannel, // Could be null
            rtcToken = newToken
        )
    }
}
```

### Solution
```kotlin
// core/call/CallManager.kt
@Singleton
class CallManager @Inject constructor(
    private val pendingCallStore: PendingCallStore
) {
    
    fun onAccepted(event: CallEvent.Accepted) {
        val current = CallStore.current()
        
        if (current == null) {
            Log.e("CALL_MANAGER", "onAccepted: No active call")
            // Emit error event
            CallEventBus.emit(
                CallEvent.Error(
                    event.callId,
                    "Cannot accept call: No active call found"
                )
            )
            return
        }
        
        // Validate required fields
        val channel = event.channel ?: current.channel
        if (channel.isNullOrBlank()) {
            Log.e("CALL_MANAGER", "onAccepted: Missing channel")
            CallEventBus.emit(
                CallEvent.Error(
                    event.callId,
                    "Cannot connect: Channel information missing"
                )
            )
            return
        }
        
        val token = event.rtcToken.ifBlank { current.rtcToken }
        if (token.isNullOrBlank()) {
            Log.e("CALL_MANAGER", "onAccepted: Missing RTC token")
            CallEventBus.emit(
                CallEvent.Error(
                    event.callId,
                    "Cannot connect: Authentication token missing"
                )
            )
            return
        }
        
        // Identity check - prevent duplicate updates
        if (current.status == CallStatus.CONNECTING &&
            current.channel == channel &&
            current.rtcToken == token
        ) {
            Log.d("CALL_MANAGER", "onAccepted: Already connecting with same params")
            return
        }
        
        // Safe update
        CallStore.update {
            it.copy(
                status = CallStatus.CONNECTING,
                channel = channel,
                rtcToken = token
            )
        }
        
        Log.d("CALL_MANAGER", "onAccepted: Updated to CONNECTING")
    }
}
```

---

## 🟡 MEDIUM-011: Duplicate Call Acceptance Memory Leak

**Severity:** Medium | **Risk:** 5/10  
**File:** `app/src/main/java/com/example/app/core/rtm/RtmEventListenerImpl.kt:48`

### Problem
```kotlin
private val acceptedCalls = ConcurrentHashMap.newKeySet<String>()

override fun onMessageEvent(event: MessageEvent) {
    when (signal.event) {
        AppConstants.EVENT_CALL_ACCEPTED -> {
            if (!acceptedCalls.add(signal.callId)) {
                Log.w("RTM", "Duplicate call_accepted ignored")
                return@launch
            }
            // ❌ Set grows indefinitely, never cleaned
        }
    }
}
```

### Solution
```kotlin
// Use LRU cache with TTL
private val acceptedCalls = object : LinkedHashMap<String, Long>(
    16, 0.75f, true
) {
    override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>): Boolean {
        // Remove entries older than 5 minutes
        return size > 100 || (System.currentTimeMillis() - eldest.value) > 300_000
    }
}

private val acceptedCallsMutex = Mutex()

override fun onMessageEvent(event: MessageEvent) {
    scope.launch {
        when (signal.event) {
            AppConstants.EVENT_CALL_ACCEPTED -> {
                val isDuplicate = acceptedCallsMutex.withLock {
                    val now = System.currentTimeMillis()
                    val lastSeen = acceptedCalls[signal.callId]
                    
                    if (lastSeen != null && (now - lastSeen) < 5000) {
                        true // Duplicate within 5 seconds
                    } else {
                        acceptedCalls[signal.callId] = now
                        false
                    }
                }
                
                if (isDuplicate) {
                    Log.w("RTM", "Duplicate call_accepted ignored for ${signal.callId}")
                    return@launch
                }
                
                CallEventBus.emit(CallEvent.Accepted(...))
            }
        }
    }
}
```

---

## 🟡 MEDIUM-012: No Validation of RTM Token Response

**Severity:** Medium | **Risk:** 4/10  
**File:** `app/src/main/java/com/example/app/MyApp.kt:88`

### Problem
```kotlin
when (val result = apiRepository.getRtmToken(accountId)) {
    is ApiResult.Success -> {
        val token = result.data // ❌ Not validated
        RtmManager.login(token)
    }
}
```

### Solution
```kotlin
when (val result = apiRepository.getRtmToken(accountId)) {
    is ApiResult.Success -> {
        val token = result.data
        
        // Validate token
        if (!isValidRtmToken(token)) {
            Log.e("RTM", "Invalid RTM token received")
            // Retry or show error
            return
        }
        
        RtmManager.init(...)
        RtmManager.login(token)
    }
}

private fun isValidRtmToken(token: String): Boolean {
    return token.isNotBlank() && 
           token.length > 20 && 
           !token.contains(" ")
}
```

---

## 🟡 MEDIUM-013: Hardcoded Notification IDs

**Severity:** Medium | **Risk:** 3/10  
**Files:** `CallForegroundService.kt`, `IncomingCallRingingService.kt`

### Problem
```kotlin
// CallForegroundService.kt
startForeground(1001, notification)

// IncomingCallRingingService.kt
startForeground(2001, notification)
```

### Solution
```kotlin
// core/notification/NotificationIds.kt
object NotificationIds {
    const val CALL_FOREGROUND_SERVICE = 1001
    const val INCOMING_CALL_RINGING = 2001
    const val INCOMING_CALL_NOTIFICATION = 3001
    const val MISSED_CALL_NOTIFICATION = 4001
    
    fun generateCallNotificationId(callId: String): Int {
        return (callId.hashCode() and 0x7FFFFFFF) % 10000 + 10000
    }
}

// Usage
startForeground(NotificationIds.CALL_FOREGROUND_SERVICE, notification)
```

---

## 🟢 LOW-002: Inconsistent Logging Tags

**Severity:** Low | **Risk:** 2/10  
**Files:** Multiple files

### Problem
```kotlin
Log.d("RTM", "...")
Log.d("RTM CONFIG", "...")
Log.d("CALL_MANAGER", "...")
```

### Solution
```kotlin
// Create consistent logging utility
object AppLog {
    private const val PREFIX = "Jugnu"
    
    object Tags {
        const val RTM = "$PREFIX:RTM"
        const val RTC = "$PREFIX:RTC"
        const val CALL = "$PREFIX:Call"
        const val NETWORK = "$PREFIX:Network"
        const val AUTH = "$PREFIX:Auth"
    }
    
    fun d(tag: String, message: String) {
        if (BuildConfig.DEBUG) {
            Log.d(tag, message)
        }
    }
}

// Usage
AppLog.d(AppLog.Tags.RTM, "Login successful")
```

---

**[← Back to UI/UX Issues](./03-UIUX-ISSUES.md) | [Continue to Architecture Issues →](./05-ARCHITECTURE-ISSUES.md)**
