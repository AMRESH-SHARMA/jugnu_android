# ⚡ PERFORMANCE & OPTIMIZATION ISSUES

**Category:** Performance  
**Total Issues:** 6 (1 Critical, 5 Medium)  
**Priority:** HIGH - Fix Within 1 Week

---

## 🔴 CRITICAL-005: Synchronous Network Call Blocking Thread

**Severity:** Critical | **Risk:** 9/10  
**File:** `app/src/main/java/com/example/app/core/remoteconfig/ConfigLoader.kt:24`  
**Impact:** ANR (Application Not Responding), App Freeze

### Problem
```kotlin
suspend fun refresh(repo: RemoteConfigRepository) {
    try {
        val request = Request.Builder()
            .url(RemoteConfig.REMOTE_CONFIG_URL)
            .build()

        client.newCall(request).execute().use { res ->  // ❌ Blocking call
            val body = res.body?.string() ?: return
            val config = json.decodeFromString<AppConfig>(body)
            // ...
        }
    } catch (e: Exception) {
        Log.e("RTM CONFIG", "❌ ConfigLoader.refresh FAILED", e)
    }
}
```

**Issues:**
- `execute()` is synchronous and blocks the calling thread
- Even though called from coroutine, it blocks the IO dispatcher thread
- Can cause ANR if called on main thread
- No timeout configured

### Impact
- **User Experience:** App freezes during config load
- **ANR Crashes:** Android kills app if main thread blocked >5s
- **Battery Drain:** Thread blocked waiting for network

### Solution

**Option 1: Use OkHttp Async (Recommended)**
```kotlin
suspend fun refresh(repo: RemoteConfigRepository) = suspendCancellableCoroutine<Unit> { continuation ->
    try {
        val request = Request.Builder()
            .url(RemoteConfig.REMOTE_CONFIG_URL)
            .build()

        val call = client.newCall(request)
        
        // Register cancellation
        continuation.invokeOnCancellation {
            call.cancel()
        }
        
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("RTM CONFIG", "❌ ConfigLoader.refresh FAILED", e)
                continuation.resume(Unit)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    try {
                        val body = res.body?.string() ?: return
                        val config = json.decodeFromString<AppConfig>(body)

                        // Update memory
                        RemoteConfig.updateApi(config.apiBaseUrl)
                        RemoteConfig.updateWs(config.wsBaseUrl)
                        RemoteConfig.updateOffer(config.offer)

                        // Persist
                        CoroutineScope(Dispatchers.IO).launch {
                            repo.saveApiBaseUrl(config.apiBaseUrl)
                            repo.saveWsBaseUrl(config.wsBaseUrl)
                        }
                        
                        continuation.resume(Unit)
                    } catch (e: Exception) {
                        Log.e("RTM CONFIG", "Parse error", e)
                        continuation.resume(Unit)
                    }
                }
            }
        })
    } catch (e: Exception) {
        Log.e("RTM CONFIG", "Request failed", e)
        continuation.resume(Unit)
    }
}
```

**Option 2: Use Retrofit (Better Architecture)**
```kotlin
// core/remoteconfig/RemoteConfigApi.kt
interface RemoteConfigApi {
    @GET
    suspend fun getConfig(@Url url: String): AppConfig
}

// core/remoteconfig/ConfigLoader.kt
@Singleton
class ConfigLoader @Inject constructor(
    private val api: RemoteConfigApi,
    private val repo: RemoteConfigRepository
) {
    suspend fun refresh() {
        try {
            val config = withTimeout(10_000) {
                api.getConfig(RemoteConfig.REMOTE_CONFIG_URL)
            }

            // Update memory
            RemoteConfig.updateApi(config.apiBaseUrl)
            RemoteConfig.updateWs(config.wsBaseUrl)
            RemoteConfig.updateOffer(config.offer)

            // Persist
            repo.saveApiBaseUrl(config.apiBaseUrl)
            repo.saveWsBaseUrl(config.wsBaseUrl)
            
            Log.d("RTM CONFIG", "RemoteConfig updated successfully")
        } catch (e: TimeoutCancellationException) {
            Log.e("RTM CONFIG", "Config fetch timeout", e)
        } catch (e: Exception) {
            Log.e("RTM CONFIG", "Config fetch failed", e)
        }
    }
}
```

---

## 🟡 MEDIUM-001: No Connection Pooling Configuration

**Severity:** Medium | **Risk:** 5/10  
**File:** `app/src/main/java/com/example/app/core/network/di/NetworkModule.kt`

### Problem
```kotlin
@Provides
@Singleton
fun provideOkHttpClient(...): OkHttpClient =
    OkHttpClient.Builder()
        .addInterceptor(...)
        .build()
```

**Issues:**
- Uses default connection pool (5 connections, 5 min keep-alive)
- No timeout configuration
- No connection reuse optimization

### Impact
- **Latency:** New connections created unnecessarily
- **Battery:** More network activity = more battery drain
- **Performance:** Slower API calls

### Solution
```kotlin
@Provides
@Singleton
fun provideOkHttpClient(
    certificatePinner: CertificatePinner,
    versionInterceptor: Interceptor,
    sessionInterceptor: SessionInterceptor,
    forceUpdateInterceptor: ForceUpdateInterceptor,
    dynamicBaseUrlInterceptor: DynamicBaseUrlInterceptor
): OkHttpClient {
    // Configure connection pool
    val connectionPool = ConnectionPool(
        maxIdleConnections = 10,
        keepAliveDuration = 30,
        timeUnit = TimeUnit.SECONDS
    )
    
    return OkHttpClient.Builder()
        .connectionPool(connectionPool)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .certificatePinner(certificatePinner)
        .addInterceptor(versionInterceptor)
        .addInterceptor(sessionInterceptor)
        .addInterceptor(forceUpdateInterceptor)
        .addInterceptor(dynamicBaseUrlInterceptor)
        .addNetworkInterceptor(createLoggingInterceptor())
        .build()
}

private fun createLoggingInterceptor(): Interceptor {
    return if (BuildConfig.DEBUG) {
        HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
    } else {
        Interceptor { chain -> chain.proceed(chain.request()) }
    }
}
```

---

## 🟡 MEDIUM-002: Unbounded SharedFlow Buffer

**Severity:** Medium | **Risk:** 5/10  
**Files:** Multiple event buses and managers

### Problem
```kotlin
// CallEventBus.kt
private val _events = MutableSharedFlow<CallEvent>(extraBufferCapacity = 16)

// RtcManager implementations
private val _events = MutableSharedFlow<RtcEvent>(extraBufferCapacity = 8)
```

**Issues:**
- Fixed buffer without overflow strategy
- If consumers slow, buffer fills and events dropped
- No backpressure handling

### Impact
- **Lost Events:** Critical call events may be dropped
- **Memory:** Buffer can grow if not consumed
- **Bugs:** Silent failures hard to debug

### Solution
```kotlin
// core/call/CallEventBus.kt
object CallEventBus {
    private val _events = MutableSharedFlow<CallEvent>(
        replay = 0,
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<CallEvent> = _events.asSharedFlow()
    
    fun emit(event: CallEvent) {
        val emitted = _events.tryEmit(event)
        if (!emitted) {
            Log.w("CallEventBus", "Event dropped (buffer full): $event")
            // Optional: Send to crash reporting
            FirebaseCrashlytics.getInstance().log("CallEvent dropped: ${event::class.simpleName}")
        }
    }
}

// For critical events, use Channel instead
class CriticalCallEventBus {
    private val _events = Channel<CallEvent>(Channel.UNLIMITED)
    val events: Flow<CallEvent> = _events.receiveAsFlow()
    
    suspend fun emit(event: CallEvent) {
        _events.send(event) // Suspends if needed, never drops
    }
}
```

---

## 🟡 MEDIUM-003: No WebSocket Timeout Configuration

**Severity:** Medium | **Risk:** 5/10  
**File:** `app/src/main/java/com/example/app/core/di/WebSocketModule.kt`

### Problem
```kotlin
@Provides
@Singleton
@Named("websocket")
fun provideWebSocketClient(): OkHttpClient {
    return OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.SECONDS) // ❌ Infinite timeout
        .build()
}
```

**Issues:**
- Infinite read timeout = zombie connections
- No ping/pong mechanism
- Stale connections not detected

### Impact
- **Resource Leak:** Dead connections consume memory
- **Battery Drain:** App thinks it's connected but isn't
- **Missed Messages:** Presence updates not received

### Solution
```kotlin
@Provides
@Singleton
@Named("websocket")
fun provideWebSocketClient(): OkHttpClient {
    return OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS) // Detect stale connections
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS) // Send ping every 20s
        .retryOnConnectionFailure(true)
        .build()
}

// Update WebSocket manager to handle pings
class PresenceWebSocketManager @Inject constructor(...) {
    
    private val socketListener = object : WebSocketListener() {
        
        override fun onOpen(webSocket: WebSocket, response: Response) {
            isConnected.set(true)
            resetBackoff()
            
            // Start heartbeat
            startHeartbeat(webSocket)
            
            scope.launch {
                PresenceEventBus.events.emit(PresenceEvent.Connected)
            }
        }
        
        // Handle pong responses
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            lastPongTime = System.currentTimeMillis()
        }
    }
    
    private var heartbeatJob: Job? = null
    private var lastPongTime = 0L
    
    private fun startHeartbeat(webSocket: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(20_000) // Every 20 seconds
                
                // Check if we received pong recently
                if (System.currentTimeMillis() - lastPongTime > 40_000) {
                    Log.w("WebSocket", "No pong received, reconnecting")
                    webSocket.close(1000, "Heartbeat timeout")
                    break
                }
                
                // Send ping
                webSocket.send("ping")
            }
        }
    }
}
```

---

## 🟡 MEDIUM-004: Inefficient JSON Parsing

**Severity:** Medium | **Risk:** 4/10  
**File:** `app/src/main/java/com/example/app/core/rtm/RtmEventListenerImpl.kt:32`

### Problem
```kotlin
override fun onMessageEvent(event: MessageEvent) {
    val rtmMessage = event.message
    val raw = rtmMessage.toString()
    
    // 🐌 Fragile string manipulation
    val jsonPayload = raw
        .substringAfter("message: ")
        .substringBefore(", data:")
    
    val signal = json.decodeFromString<CallSignalPayload>(jsonPayload)
}
```

**Issues:**
- String manipulation is fragile
- Breaks if RTM message format changes
- CPU overhead for string operations

### Impact
- **Parsing Failures:** Silent failures if format changes
- **Performance:** Unnecessary string operations
- **Maintenance:** Hard to debug

### Solution

**Option 1: Parse entire message properly**
```kotlin
@Serializable
data class RtmMessageWrapper(
    val message: CallSignalPayload,
    val data: String? = null
)

override fun onMessageEvent(event: MessageEvent) {
    try {
        val rtmMessage = event.message
        val messageData = rtmMessage.getData() // Get raw bytes
        
        val wrapper = json.decodeFromString<RtmMessageWrapper>(
            messageData.toString(Charsets.UTF_8)
        )
        
        handleCallSignal(wrapper.message)
    } catch (e: Exception) {
        Log.e("RTM", "Failed to parse RTM message", e)
        FirebaseCrashlytics.getInstance().recordException(e)
    }
}
```

**Option 2: Use Agora's message type properly**
```kotlin
override fun onMessageEvent(event: MessageEvent) {
    try {
        val message = event.message
        
        // Use Agora's built-in methods
        val payload = when {
            message.messageType == RtmMessageType.TEXT -> {
                json.decodeFromString<CallSignalPayload>(message.text)
            }
            message.messageType == RtmMessageType.BINARY -> {
                json.decodeFromString<CallSignalPayload>(
                    message.rawMessage.toString(Charsets.UTF_8)
                )
            }
            else -> {
                Log.w("RTM", "Unknown message type: ${message.messageType}")
                return
            }
        }
        
        handleCallSignal(payload)
    } catch (e: Exception) {
        Log.e("RTM", "Failed to parse RTM message", e)
    }
}
```

---

## 🟡 MEDIUM-005: No Caching Strategy for Remote Config

**Severity:** Medium | **Risk:** 4/10  
**File:** `app/src/main/java/com/example/app/MyApp.kt:48`

### Problem
```kotlin
appScope.launch(Dispatchers.IO) {
    if (AppConstants.USE_DEFAULT_URL) {
        RemoteConfig.updateApi(AppConstants.DEFAULT_BASE_URL)
    } else {
        // 1️⃣ load cached value (fast)
        val cached = remoteConfigRepo.loadApiBaseUrl()
        if (cached != null) RemoteConfig.updateApi(cached)
        // 2️⃣ fetch GitHub config (background)
        ConfigLoader.refresh(remoteConfigRepo)
    }
}
```

**Issues:**
- Config fetched every app start
- No TTL (Time To Live)
- No cache invalidation strategy
- Unnecessary network calls

### Impact
- **Slow Startup:** App waits for config fetch
- **Battery Drain:** Unnecessary network calls
- **Data Usage:** Wasted bandwidth

### Solution
```kotlin
// core/remoteconfig/RemoteConfigRepository.kt
@Singleton
class RemoteConfigRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    companion object {
        val KEY_API_BASE_URL = stringPreferencesKey("api_base_url")
        val KEY_WS_BASE_URL = stringPreferencesKey("ws_base_url")
        val KEY_CONFIG_TIMESTAMP = longPreferencesKey("config_timestamp")
        
        private const val CONFIG_TTL_MS = 3600_000L // 1 hour
    }
    
    suspend fun shouldRefreshConfig(): Boolean {
        val lastFetch = dataStore.data.first()[KEY_CONFIG_TIMESTAMP] ?: 0L
        val now = System.currentTimeMillis()
        return (now - lastFetch) > CONFIG_TTL_MS
    }
    
    suspend fun saveConfig(
        apiBaseUrl: String,
        wsBaseUrl: String
    ) {
        dataStore.edit { prefs ->
            prefs[KEY_API_BASE_URL] = apiBaseUrl
            prefs[KEY_WS_BASE_URL] = wsBaseUrl
            prefs[KEY_CONFIG_TIMESTAMP] = System.currentTimeMillis()
        }
    }
    
    suspend fun loadCachedConfig(): Pair<String?, String?> {
        val prefs = dataStore.data.first()
        return Pair(
            prefs[KEY_API_BASE_URL],
            prefs[KEY_WS_BASE_URL]
        )
    }
}

// MyApp.kt
appScope.launch(Dispatchers.IO) {
    // Load cached config immediately
    val (cachedApi, cachedWs) = remoteConfigRepo.loadCachedConfig()
    if (cachedApi != null) RemoteConfig.updateApi(cachedApi)
    if (cachedWs != null) RemoteConfig.updateWs(cachedWs)
    
    // Refresh only if TTL expired
    if (remoteConfigRepo.shouldRefreshConfig()) {
        ConfigLoader.refresh(remoteConfigRepo)
    }
}
```

---

## 🟡 MEDIUM-006: No Request Cancellation on Screen Exit

**Severity:** Medium | **Risk:** 4/10  
**Files:** All ViewModels making API calls

### Problem
```kotlin
// OtpViewModel.kt
fun verifyOtp(phone: String, otp: String) {
    viewModelScope.launch {
        _otpVerifyState.value = OtpUiState.Loading
        val result = verifyOtpUseCase(phone, otp, fcmToken)
        // If user navigates away, this continues
    }
}
```

**Issues:**
- API calls continue after screen closed
- Wasted network/battery
- Potential memory leaks

### Impact
- **Battery Drain:** Unnecessary network activity
- **Memory:** Callbacks hold references
- **Bugs:** State updates after screen destroyed

### Solution
```kotlin
// Use viewModelScope (already cancels on clear)
// But add explicit cancellation for long operations

class OtpViewModel @Inject constructor(...) : ViewModel() {
    
    private var verifyJob: Job? = null
    
    fun verifyOtp(phone: String, otp: String) {
        // Cancel previous request
        verifyJob?.cancel()
        
        verifyJob = viewModelScope.launch {
            _otpVerifyState.value = OtpUiState.Loading
            
            try {
                val result = withTimeout(30_000) {
                    verifyOtpUseCase(phone, otp, fcmToken)
                }
                
                when (result) {
                    is ApiResult.Success -> {
                        _otpVerifyState.value = OtpUiState.Success(result.data)
                    }
                    is ApiResult.Error -> {
                        _otpVerifyState.value = OtpUiState.Error(
                            result.message ?: "Verification failed"
                        )
                    }
                }
            } catch (e: TimeoutCancellationException) {
                _otpVerifyState.value = OtpUiState.Error("Request timeout")
            } catch (e: CancellationException) {
                // Request cancelled, don't update state
                Log.d("OtpViewModel", "Verification cancelled")
            }
        }
    }
    
    override fun onCleared() {
        verifyJob?.cancel()
        super.onCleared()
    }
}
```

---

**[← Back to Security Issues](./01-SECURITY-ISSUES.md) | [Continue to UI/UX Issues →](./03-UIUX-ISSUES.md)**
